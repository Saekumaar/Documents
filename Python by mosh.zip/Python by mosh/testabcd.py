import a
import b

def main():
    print(a.f1())
    print(b.f2())
    
if __name__ == "__main__":
    main()
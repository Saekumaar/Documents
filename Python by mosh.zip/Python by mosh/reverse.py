def revese_words(s):
    return ' '.join(reversed(s.split()))
    # words=s.split()
    # words.reverse()
    # return ' '.join(words)
S=input("Enter a string:")
print("Reversed string : ",revese_words(S))
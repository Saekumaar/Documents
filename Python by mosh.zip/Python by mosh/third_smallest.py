def third_smallest(num):
	if len(num) < 3:
		return None
	smallest = num[0]
	second = num[1]
	third = num[2]
	if second < smallest:
		smallest, second = second, smallest
	elif third < smallest: 
		smallest, third = third, smallest
	elif third < second:
		second, third = third, second
	
	for i in range(3, len(num)):
		if num[i] < smallest:
			third = second
			second = smallest
			smallest = num[i]
		elif num[i] < second:
			third = second
			second = num[i]
		elif num[i] < third:
			third = num[i]	
	return third

number = [12, 45, 3, 15, 11 , 2, 2, 2, 3, 12, 9, 24]
print(third_smallest(number))
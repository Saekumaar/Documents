def second_smallest(num):
	if len(num) < 2:
		return None
	smallest =num[0]
	second = num[1]
	if second < smallest:
		smallest, second = second, smallest
	for i in range(2,len(num)):
		if num[i] < smallest:
			second = smallest
			smallest = num[i]
		elif smallest < num[i] < second:
			second = num[i]

	return second

number = [12, 23, 11, 9, 24]
print(second_smallest(number))

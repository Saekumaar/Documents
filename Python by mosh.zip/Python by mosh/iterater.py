class count:
    def __init__(self,limit):
        self.num=1
        self.limit=limit
    def __iter__(self):
        return self
    def __next__(self):
        for i in range(self.num, self.limit+1):
            self.num +=1
            return i
        raise StopIteration
c=count(5)
for i in c:
    print(i)
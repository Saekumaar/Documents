def Vow(s):
    # count=0
    return sum(1 for i in s.lower() if i in "aeiou")
    # for i in s.lower():
    #     if i in "aeiou":
    #         count+=1
    # return count
V=input("Enter a string : ")
print("Number of vowels in the string : ",Vow(V))
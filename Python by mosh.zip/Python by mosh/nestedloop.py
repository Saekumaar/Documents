number = [5, 2, 5, 2, 2]
for x in number:
    for y in range(x):
        print("x", end="")
    print()
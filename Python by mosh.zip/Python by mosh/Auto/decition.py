import pandas as pd

# Read CSV file
df = pd.read_csv("cust.csv")

# Display first few rows
print(df.head())

# Get basic information
print(df.info())

# Select a column
print(df["name"])

# Filter rows (age > 26)
filtered_df = df[df["age"] > 26]
print(filtered_df)

# Add a new column
df["bonus"] = df["salary"] * 0.10

# Update a value
df.loc[df["name"] == "Alice", "salary"] = 52000

# Save updated data to a new CSV
df.to_csv("updated_data.csv", index=False)

print("CSV processing completed successfully.")
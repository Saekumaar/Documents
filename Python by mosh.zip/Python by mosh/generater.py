class odd:
    def count(self):
        num=1
        while num<=self.limit:
            yield num
            num+=2
e=odd()
e.limit=10  
for i in e.count():
    print(i)
Command = " "
started = False
stoped = False
while True:
    Command = input("> ").lower()
    if Command == "start":
        if started:
            print("Car is already started!")
        else:
            started = True
            stoped = False
            print("Car started...Ready to go!")
    elif Command == "stop":
        if stoped:
            print("Car is already stoped!")
        else:
            stoped = True           
            started = False
            print("Car stopped.")
    elif Command == "help":
        print("""
        start - start the car,
        stop - stop it,
        and quit - to exit.
              """)
    elif Command == "quit":
        break
    else:
        print("Sorry, I don't understand that...") 
     

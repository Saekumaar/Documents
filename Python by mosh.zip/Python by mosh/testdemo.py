print("beginning of testdemo.py file")
import demo
import math
c=300
d=400
def f2():
    print("This is function f2")
print(c)
print(d)
f2()
print(demo.a)
print(demo.b)
print(demo.f1())
print(dir())
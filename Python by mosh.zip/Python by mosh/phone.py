phone = input("enter a number: ")
if phone.isdigit():
    number = int(phone)
    print("Valid phone number: ", number)
else:
    print("Invalid phone number")
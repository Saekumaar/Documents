items = [1,3,5,3,1,2,4,2]
#print(list(dict.fromkeys(items))) # for not to get order
#print(list(set(items))) # for get order
unique_items = [] 
for i in items:
    if i not in unique_items:
        unique_items.append(i)
print(unique_items) 
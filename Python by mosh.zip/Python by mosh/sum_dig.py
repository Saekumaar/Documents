def sum(num):
    count = 0
    for i in num:
        if i % 2 == 0:
            count += i
    return count
number = [1, 2, 3, 4, 5]    
print(sum(number))
import maxi
numbers = [10, 20, 30, 40, 50]
x= maxi.find_max(numbers)
print(f"Maximum number: {x}")
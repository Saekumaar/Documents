list = [1, 2, 3, 4, 5, 5,6]
numbers = []
for number in list:
    if number not in numbers:
        numbers.append(number)
print(numbers)
def squire(n):
    for i in range(n):
        yield i*i
print(squire(10))
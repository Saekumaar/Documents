name = "John smith"
age = 20
is_new = True
print("patient name is :" + name + " and age is :" + str(age))
class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def talk(self):
        print(f"{self.name} is talking")
t1 = Person("Sagar", 30)
t1.talk()
class Calculator:
    def __init__(self):
        self.result = 0

    def add(self, x, y):
        try:
            self.result = x + y
        except Exception as e:
            print(f"An error occurred: {e}")
        return self.result

    def subtract(self, x, y):
        try:
            self.result = x - y
        except Exception as e:
            print(f"An error occurred: {e}")
        return self.result
    

Z = Calculator()
x = float(input("Enter the first number: "))
y = float(input("Enter the second number: "))
result = Z.add(x, y)
print(f"Addition result: {result}")
result = Z.subtract(x, y)
print(f"Subtraction result: {result}")

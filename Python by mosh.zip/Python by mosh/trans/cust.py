from pathlib import Path
import openpyxl as xl
xlsx= Path(__file__).resolve().parent / "cust.xlsx"
wb = xl.load_workbook(xlsx)
sheet = wb['Sheet1']
cell = sheet['A1']
print(cell.value)
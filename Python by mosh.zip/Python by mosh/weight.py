weight = int(input("What is your weight? "))
value= input("Is the weight in (K)ilograms or (P)ounds? ")
if value.upper() == "K":
    weight_in_pounds = weight / 0.45
    print(f"Your weight in pounds is: {weight_in_pounds}")
else:
    weight_in_kilograms = weight * 0.45
    print(f"Your weight in kilograms is: {weight_in_kilograms}")
    
a=100
b=200
def f1():
    print("This is function f1")    
print("end")
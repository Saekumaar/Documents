c=3000 
def f3():
    print("in f3 of pack1.spack1.c")
def count_dig(n):
    return len(str(abs(n)))
    # count = 0
    # if n == 0:
    #     return 1
    # while n>0:
    #     n //= 10
    #     count += 1
    # return count
number = int(input("Enter a number : "))
print("Number of digits in the number : ",count_dig(number))
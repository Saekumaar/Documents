d=4000  
def f4():
    print("in f4 of pack1.subpack.d")
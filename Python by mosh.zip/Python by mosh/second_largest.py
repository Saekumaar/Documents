def second_largest(num):
	if len(num) < 2:
		return None
	
	largest = num[0]
	second = num[1]
	
	if second > largest:
		largest, second = second, largest
	
	for i in range(2, len(num)):
		if largest < num[i]:
			largest = second
			num[i] = largest
			
		elif num[i] > second and num[i]!= largest:
			second = num[i]
	
	return second

number =[1,24,35,12,25]
print(second_largest(number))
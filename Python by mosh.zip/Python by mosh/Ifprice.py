Price = 1000000
is_credit_good = False
if is_credit_good:
    down_payment = 0.1 * int(Price)
else:
    down_payment = 0.2 * int(Price)
print(f"Down payment is: ${down_payment}")
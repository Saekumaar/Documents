list = [1, 2, 8, 10, 5]
number = list[0]
for n in list:
    if n > number:
        number = n
print(number)
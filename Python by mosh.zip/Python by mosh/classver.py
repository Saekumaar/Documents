class test:
    a=100
    b=200
    def display(self):
        print(test.b)
        print(self.a)
        print(self.b)   
    def modify(self):
        test.a=test.a+300

t1=test()
t1.display()
print(test.a)
print(t1.a)
t1.modify()
print(test.a)
print(t1.a)
t2=test()
t2.modify()
print(test.a)